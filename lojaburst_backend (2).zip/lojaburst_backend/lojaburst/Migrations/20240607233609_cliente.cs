﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace lojaburst.Migrations
{
    /// <inheritdoc />
    public partial class cliente : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Senha = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Produtos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Imagem = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Nome = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Categoria = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Subcategoria = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Descricao = table.Column<string>(type: "text", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Valor = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    QuantidadeEstoque = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produtos", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.InsertData(
                table: "Produtos",
                columns: new[] { "Id", "Categoria", "Descricao", "Imagem", "Nome", "QuantidadeEstoque", "Subcategoria", "Valor" },
                values: new object[,]
                {
                    { 1, "Categoria 1", "Descrição do Produto 1", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 1", 7, "Subcategoria 1", 10.99m },
                    { 2, "Categoria 1", "Descrição do Produto 2", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 2", 8, "Subcategoria 2", 20.49m },
                    { 3, "Categoria 1", "Descrição do Produto 3", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 3", 1, "Subcategoria 1", 30.99m },
                    { 4, "Categoria 1", "Descrição do Produto 4", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 4", 3, "Subcategoria 2", 25.49m },
                    { 5, "Categoria 1", "Descrição do Produto 5", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 5", 27, "Subcategoria 3", 18.99m },
                    { 6, "Categoria 1", "Descrição do Produto 6", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 6", 98, "Subcategoria 1", 22.99m },
                    { 7, "Categoria 1", "Descrição do Produto 7", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 7", 88, "Subcategoria 2", 17.49m },
                    { 8, "Categoria 1", "Descrição do Produto 8", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 8", 108, "Subcategoria 3", 33.99m },
                    { 9, "Categoria 1", "Descrição do Produto 9", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 9", 972, "Subcategoria 1", 28.99m },
                    { 10, "Categoria 1", "Descrição do Produto 10", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 10", 52, "Subcategoria 2", 21.49m },
                    { 11, "Categoria 1", "Descrição do Produto 12", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 12", 62, "Subcategoria 1", 29.99m },
                    { 12, "Categoria 1", "Descrição do Produto 13", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 13", 20, "Subcategoria 2", 24.49m },
                    { 13, "Categoria 1", "Descrição do Produto 14", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 14", 18, "Subcategoria 3", 19.99m },
                    { 14, "Categoria 1", "Descrição do Produto 15", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 15", 63, "Subcategoria 1", 27.99m },
                    { 15, "Categoria 1", "Descrição do Produto 16", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 16", 41, "Subcategoria 2", 23.49m },
                    { 16, "Categoria 1", "Descrição do Produto 17", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 17", 25, "Subcategoria 3", 16.99m },
                    { 17, "Categoria 1", "Descrição do Produto 18", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 18", 18, "Subcategoria 1", 31.99m },
                    { 18, "Categoria 1", "Descrição do Produto 19", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 19", 17, "Subcategoria 2", 26.49m },
                    { 19, "Categoria 1", "Descrição do Produto 20", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 20", 99, "Subcategoria 3", 20.99m },
                    { 20, "Categoria 1", "Descrição do Produto 21", "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", "Produto 21", 450, "Subcategoria 1", 35.99m }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clientes");

            migrationBuilder.DropTable(
                name: "Produtos");
        }
    }
}
