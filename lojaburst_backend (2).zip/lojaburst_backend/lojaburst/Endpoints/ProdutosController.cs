﻿using lojaburst.Database;
using lojaburst.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace lojaburst.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        private readonly projetotrayDbContext _context;

        public ProdutoController(projetotrayDbContext context)
        {
            _context = context;
        }

        [HttpGet("exibirProdutos")]
        public async Task<IActionResult> GetAll()
        {
            var produtos = await _context.Produtos.ToListAsync();
            return Ok(produtos);
        }

        [HttpGet("exibirProduto/{id}")]
        public async Task<IActionResult> GetProduto(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null)
            {
                return NotFound();
            }
            return Ok(produto);
        }

        [HttpPut("updateProduto/{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Produto produto)
        {
            var produtoExistente = await _context.Produtos.FindAsync(id);
            if (produtoExistente == null) return NotFound();

            produtoExistente.Imagem = produto.Imagem;
            produtoExistente.Nome = produto.Nome;
            produtoExistente.Categoria = produto.Categoria;
            produtoExistente.Subcategoria = produto.Subcategoria;
            produtoExistente.Descricao = produto.Descricao;
            produtoExistente.Valor = produto.Valor;
            produtoExistente.QuantidadeEstoque = produto.QuantidadeEstoque;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("deleteProduto/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null) return NotFound();

            _context.Produtos.Remove(produto);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
