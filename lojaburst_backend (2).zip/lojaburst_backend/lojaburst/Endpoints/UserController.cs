﻿using lojaburst.Database;
using lojaburst.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace lojaburst.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly projetotrayDbContext _context;

        public UserController(projetotrayDbContext context)
        {
            _context = context;
        }

        [HttpPost("addCliente")]
        public async Task<IActionResult> Create([FromBody] Cliente cliente)
        {
            _context.Clientes.Add(cliente);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Create), new { id = cliente.Id }, cliente);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel login)
        {
            var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == login.Email && c.Senha == login.Senha);
            if (cliente == null)
            {
                return Unauthorized();
            }
            return Ok(cliente);
        }
    }

    public class LoginModel
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
