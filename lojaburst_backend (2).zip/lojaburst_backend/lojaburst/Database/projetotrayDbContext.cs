﻿using Microsoft.EntityFrameworkCore;
using lojaburst.Models;

namespace lojaburst.Database
{
    public class projetotrayDbContext : DbContext
    {
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Cliente> Clientes { get; set; } 

        public projetotrayDbContext(DbContextOptions<projetotrayDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Produto>(entity =>
            {
                entity.ToTable("Produtos");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Imagem).IsRequired();
                entity.Property(e => e.Nome).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Categoria).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Subcategoria).HasMaxLength(50);
                entity.Property(e => e.Descricao).HasColumnType("text");
                entity.Property(e => e.Valor).HasColumnType("decimal(18,2)");
                entity.Property(e => e.QuantidadeEstoque).HasColumnType("int");
            });

            modelBuilder.Entity<Cliente>(entity =>
            {
                entity.ToTable("Clientes");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Senha).IsRequired().HasMaxLength(100);
            });

            // Popula o banco 
            modelBuilder.Entity<Produto>().HasData(
                new Produto { Id = 1, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 1", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 1", Valor = 10.99m, QuantidadeEstoque = 7 },
                new Produto { Id = 2, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 2", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 2", Valor = 20.49m, QuantidadeEstoque = 8 },
                new Produto { Id = 3, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 3", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 3", Valor = 30.99m, QuantidadeEstoque = 1 },
                new Produto { Id = 4, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 4", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 4", Valor = 25.49m, QuantidadeEstoque = 3 },
                new Produto { Id = 5, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 5", Categoria = "Categoria 1", Subcategoria = "Subcategoria 3", Descricao = "Descrição do Produto 5", Valor = 18.99m, QuantidadeEstoque = 27 },
                new Produto { Id = 6, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 6", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 6", Valor = 22.99m, QuantidadeEstoque = 98 },
                new Produto { Id = 7, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 7", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 7", Valor = 17.49m, QuantidadeEstoque = 88 },
                new Produto { Id = 8, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 8", Categoria = "Categoria 1", Subcategoria = "Subcategoria 3", Descricao = "Descrição do Produto 8", Valor = 33.99m, QuantidadeEstoque = 108 },
                new Produto { Id = 9, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 9", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 9", Valor = 28.99m, QuantidadeEstoque = 972 },
                new Produto { Id = 10, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 10", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 10", Valor = 21.49m, QuantidadeEstoque = 52 },
                new Produto { Id = 11, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 12", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 12", Valor = 29.99m, QuantidadeEstoque = 62 },
                new Produto { Id = 12, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 13", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 13", Valor = 24.49m, QuantidadeEstoque = 20 },
                new Produto { Id = 13, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 14", Categoria = "Categoria 1", Subcategoria = "Subcategoria 3", Descricao = "Descrição do Produto 14", Valor = 19.99m, QuantidadeEstoque = 18 },
                new Produto { Id = 14, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 15", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 15", Valor = 27.99m, QuantidadeEstoque = 63 },
                new Produto { Id = 15, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 16", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 16", Valor = 23.49m, QuantidadeEstoque = 41 },
                new Produto { Id = 16, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 17", Categoria = "Categoria 1", Subcategoria = "Subcategoria 3", Descricao = "Descrição do Produto 17", Valor = 16.99m, QuantidadeEstoque = 25 },
                new Produto { Id = 17, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 18", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 18", Valor = 31.99m, QuantidadeEstoque = 18 },
                new Produto { Id = 18, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 19", Categoria = "Categoria 1", Subcategoria = "Subcategoria 2", Descricao = "Descrição do Produto 19", Valor = 26.49m, QuantidadeEstoque = 17 },
                new Produto { Id = 19, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 20", Categoria = "Categoria 1", Subcategoria = "Subcategoria 3", Descricao = "Descrição do Produto 20", Valor = 20.99m, QuantidadeEstoque = 99 },
                new Produto { Id = 20, Imagem = "https://as1.ftcdn.net/v2/jpg/02/65/68/34/1000_F_265683485_SrQP36roamZV47f9zveHM0ULNeEyieM0.jpg", Nome = "Produto 21", Categoria = "Categoria 1", Subcategoria = "Subcategoria 1", Descricao = "Descrição do Produto 21", Valor = 35.99m, QuantidadeEstoque = 450 }
            );
        }
    }
}
